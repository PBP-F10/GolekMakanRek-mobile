package com.example.golekmakanrek_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
